function cobwebLine(x)
% generate the cobweb plot associated with
% the orbits x_n+1=f(x_n).
% N is the number of iterates, and
% (a,b) is the interval
% x0 and x1 are two initial points.
% use @f to pass function ...
N=length(x)-1;
green=matlabGreen;
% turn hold on to gather up all plots in one
hold on;
plot(x(1),x(1),'o','color',green,'markerfacecolor',green)

for i=1:N
    plot([x(i),x(i),x(i+1)],[x(i),x(i+1),x(i+1)],'color',green);
end

hold off;
