function fn=nthIterate(f,n)

fn=@(x)f(x);
for k=2:n
    fn=@(x)f(fn(x));
end