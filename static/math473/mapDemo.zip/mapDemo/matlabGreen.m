function green=matlabGreen
green=[0.4660    0.6740    0.1880];