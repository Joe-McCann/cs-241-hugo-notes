function x=iterateMap(f,x0,N)
% generate the cobweb plot associated with
% the orbits x_n+1=f(x_n).
% N is the number of iterates, and
% x0 is the initial point
% use @f to pass function ...
x=zeros(1,N+1);
x(1)=x0;

for i=1:N
    x(i+1)=f(x(i));
end