function lambda=liapunov1D(fprime,x)
lambda=mean(log(abs(fprime(x))));