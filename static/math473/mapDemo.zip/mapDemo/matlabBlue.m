function blue=matlabBlue
 blue=[0    0.4470    0.7410];