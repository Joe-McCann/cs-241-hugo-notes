function x=cobweb(f,interval,x0,N,pauseFlag)
% generate the cobweb plot associated with
% the orbits x_n+1=f(x_n).
% N is the number of iterates, and
% (a,b) is the interval
% x0 and x1 are two initial points.
% use @f to pass function ...
if ~exist('pauseFlag','var')
    pauseFlag=false;
end

red=matlabRed;
blue=matlabBlue;

% generate N linearly space values on (a,b)
%X=linspace(interval(1),interval(2),50);  
% which we use to plot the function y=f(x)
%y=f(X);

% turn hold on to gather up all plots in one
clf; hold on;
fplot(f,interval,'k'); % plot the function
fplot(@(x)x,interval,'color',red); % plot the straight line
xlabel('$x_n$')
ylabel('$x_{n+1}$')
axis equal square
x=zeros(1,N+1);
x(1)=x0; % plot orbit starting at x0
plot(x0,x0,'o','color',blue,'markerfacecolor',blue)
if pauseFlag; fprintf('x(1)= %0.3f\n',x0);end
for i=1:N
    x(i+1)=f(x(i));
    plot([x(i),x(i),x(i+1)],[x(i),x(i+1),x(i+1)],'color',blue);
    if pauseFlag
        fprintf('x(%i) = %0.3f \n',i+1,x(i+1));
        pause; 
    end
end

hold off;
