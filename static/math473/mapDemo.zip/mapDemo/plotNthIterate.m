function plotNthIterate(f,n,I)
fn=nthIterate(f,n);
clf;
hold on;
fplot(fn,I)
fplot(@(x)x,I)
axis square equal tight
hold off