function red=matlabRed
red=[ 0.8500    0.3250    0.0980];